import { NextRequest, NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { RUDIN_PROPERTIES, EVENT_SOURCES, EVENT_CATEGORIES } from "../../data/properties";

const client = new Anthropic();

export interface DiscoveredEvent {
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  sourceWebsite: string;
  sourceUrl: string;
  category: string;
  nearestProperties: string[];
  neighborhood: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      selectedNeighborhoods = [],
      selectedCategories = EVENT_CATEGORIES,
      dateRangeDays = 30,
      propertyType = "Both",
    } = body;

    // Filter properties
    let properties = RUDIN_PROPERTIES;
    if (propertyType === "Commercial") properties = properties.filter(p => p.type === "Commercial");
    if (propertyType === "Residential") properties = properties.filter(p => p.type === "Residential");
    if (selectedNeighborhoods.length > 0) {
      properties = properties.filter(p => selectedNeighborhoods.includes(p.neighborhood));
    }

    const neighborhoodList = [...new Set(properties.map(p => p.neighborhood))];
    const bidList = EVENT_SOURCES.filter(s => s.type === "BID").map(s => `${s.name} (${s.url})`).join(", ");
    const categoryList = selectedCategories.join(", ");

    const prompt = `You are an AI assistant helping Rudin Management Company's Marketing team discover local community events near their NYC properties.

Search for upcoming community events in the next ${dateRangeDays} days near these NYC neighborhoods: ${neighborhoodList.join(", ")}.

Focus on these event categories: ${categoryList}

Priority sources to search (Business Improvement Districts and trusted community sites):
${EVENT_SOURCES.map(s => `- ${s.name}: ${s.url}`).join("\n")}

Rudin properties in these neighborhoods:
${properties.map(p => `- ${p.name} (${p.address}) — ${p.neighborhood}`).join("\n")}

Instructions:
1. Search the web for real upcoming events from the BID websites and trusted community sources listed above
2. Find 15-25 events across the neighborhoods
3. For each event, identify which Rudin properties are closest (within ~1 mile)
4. Return ONLY a valid JSON array. No markdown, no explanation, just the JSON array.

Return this exact JSON structure:
[
  {
    "title": "Event name",
    "description": "2-3 sentence summary of the event",
    "date": "Month Day, Year (e.g. July 20, 2025)",
    "time": "Start time (e.g. 6:00 PM) or TBD",
    "location": "Full venue name and address",
    "sourceWebsite": "Name of the website/BID where this was found",
    "sourceUrl": "Direct URL to the event page",
    "category": "One of: Arts & Culture, Food & Drink, Fitness & Wellness, Family-Friendly, Networking & Business, Seasonal & Holiday, Community & Civic, Music & Entertainment",
    "nearestProperties": ["Property Name 1", "Property Name 2"],
    "neighborhood": "Neighborhood name"
  }
]

Search actual BID event pages and community sites. Return real events if found, or realistic placeholder events based on typical programming from these BIDs if live search is unavailable. Always cite the source URL.`;

    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 8000,
      tools: [
        {
          type: "web_search_20250305" as const,
          name: "web_search",
        } as any,
      ],
      messages: [{ role: "user", content: prompt }],
    });

    // Extract the final text response
    let rawText = "";
    for (const block of response.content) {
      if (block.type === "text") {
        rawText += block.text;
      }
    }

    // Parse JSON from response
    let events: DiscoveredEvent[] = [];
    try {
      const jsonMatch = rawText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        events = JSON.parse(jsonMatch[0]);
      }
    } catch {
      // Try stripping markdown fences
      const clean = rawText.replace(/```json|```/g, "").trim();
      const jsonMatch2 = clean.match(/\[[\s\S]*\]/);
      if (jsonMatch2) {
        events = JSON.parse(jsonMatch2[0]);
      }
    }

    return NextResponse.json({ events, total: events.length });
  } catch (error: any) {
    console.error("Search error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to search events" },
      { status: 500 }
    );
  }
}
